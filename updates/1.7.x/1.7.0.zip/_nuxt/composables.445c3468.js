import{a1 as a}from"./entry.dbe97474.js";function s(e,u){return a()._useHead(e,u)}export{s as u};
