import{Y as r}from"./entry.45cef33a.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
