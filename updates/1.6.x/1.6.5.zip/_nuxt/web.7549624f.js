import{a0 as n}from"./entry.4cff0d8f.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
