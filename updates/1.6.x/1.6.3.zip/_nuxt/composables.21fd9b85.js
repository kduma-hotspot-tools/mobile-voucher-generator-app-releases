import{Y as r}from"./entry.4cff0d8f.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
