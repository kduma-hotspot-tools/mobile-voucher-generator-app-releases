import{a0 as n}from"./entry.57c9b7f1.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
