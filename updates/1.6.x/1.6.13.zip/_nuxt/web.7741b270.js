import{a4 as n}from"./entry.caaff1c5.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
