import{a1 as a}from"./entry.88331c34.js";function s(e,u){return a()._useHead(e,u)}export{s as u};
