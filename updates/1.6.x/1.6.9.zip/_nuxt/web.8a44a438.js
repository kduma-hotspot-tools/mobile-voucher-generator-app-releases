import{a4 as n}from"./entry.88331c34.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
