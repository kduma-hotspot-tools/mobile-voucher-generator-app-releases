import{a0 as n}from"./entry.00511c08.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
