import{a0 as n}from"./entry.01e7459a.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
