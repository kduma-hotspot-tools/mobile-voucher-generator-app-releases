import{Y as r}from"./entry.2813ca71.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
