import{a0 as n}from"./entry.001c5d91.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
