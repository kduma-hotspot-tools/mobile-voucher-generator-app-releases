import{P as r}from"./entry.cee15de0.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
