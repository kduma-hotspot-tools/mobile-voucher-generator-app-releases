import{a4 as n}from"./entry.cee15de0.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
