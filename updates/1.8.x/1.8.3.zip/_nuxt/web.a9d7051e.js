import{a4 as n}from"./entry.8cf6afc3.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
