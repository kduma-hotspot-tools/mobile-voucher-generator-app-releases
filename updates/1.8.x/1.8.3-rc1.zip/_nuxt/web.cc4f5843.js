import{a4 as n}from"./entry.6f5620cd.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
