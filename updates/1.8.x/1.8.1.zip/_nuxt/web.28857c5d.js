import{a4 as n}from"./entry.2eaa18c7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
