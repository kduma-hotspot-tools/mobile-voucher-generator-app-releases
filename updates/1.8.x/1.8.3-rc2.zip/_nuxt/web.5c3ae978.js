import{a4 as n}from"./entry.c01c7b01.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
