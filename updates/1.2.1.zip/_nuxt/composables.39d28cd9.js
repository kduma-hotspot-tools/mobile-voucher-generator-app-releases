import{Y as r}from"./entry.8e21cb9d.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
