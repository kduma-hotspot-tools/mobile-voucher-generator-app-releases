import{Y as r}from"./entry.cd99a388.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
